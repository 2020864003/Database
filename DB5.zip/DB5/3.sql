declare
    type s_ty is table of studio%rowtype;
    type m_ty is table of movieexec%rowtype;
    type ms_ty is table of starsin%rowtype;
    type mv_ty is table of moviestar%rowtype;
    
    mv   mv_ty;
    me   m_ty;
    stu  s_ty;
    ms   ms_ty;
    
    cursor m_csr is select * from movieexec order by name asc;
    cursor s_csr(pno movieexec.certno%type) 
                is select * from studio where pno = presno;
    cursor ss_csr(sname movieexec.name%type) is select * from starsin where  starname in(select name
                                                                                         from moviestar,starsin
                                                                                        where name = starname and name = sname)order by starname asc;
    cursor ms_csr(sname movieexec.name%type) is select * from moviestar where  name in(select name
                                                                                       from moviestar,starsin
                                                                                       where name = starname and name = sname)order by name asc;
    cnt    integer;
    gen    moviestar.gender%type;
    
    maxy   movie.year%type;
    miny   movie.year%type;
begin
    for m in m_csr loop

        open s_csr(m.certno);
            fetch s_csr BULK COLLECT INTO stu;
        close s_csr;
        dbms_output.put_line('제작자['||m.name||'] : 주소['||m.address||'], 재산['||m.networth||']');
        dbms_output.put('   운영영화사 : ');
        if stu.count > 0 then
         dbms_output.put_line('');   
             for i in stu.first..stu.last loop
                dbms_output.put_line('             이름['||stu(i).name||'] ,'||'사무실 주소 ['||stu(i).address||']');
             end loop;
        else
            dbms_output.put_line('없음');
        end if;
       
        open ms_csr(m.name);
            fetch ms_csr bulk collect into mv;
        close ms_csr;
        
        open ss_csr(m.name);
            fetch ss_csr bulk collect into ms;
        close ss_csr;
     
        if ms.count > 0 then
            for i in mv.first..mv.last loop
                if mv(i).gender = 'female' then
                     dbms_output.put_line('   배우경력 : 성별[여자], 총 편수['||ms.count||'편]');
                     for i in ms.first..ms.last loop
                         dbms_output.put_line('             최초 출연 영화 : '||ms(i).movietitle||'['||ms(i).movieyear||'년]');
                         dbms_output.put_line('             최초 출연 영화 : '||ms(i).movietitle||'['||ms(i).movieyear||'년]');
                         end loop;
                else
                     dbms_output.put_line('   배우경력 : 성별[남자], 총 편수['||ms.count||'편]');
                     for i in ms.first..ms.last loop
                         if i = 1 then
                            if ms.count = 1 then
                            dbms_output.put_line('             최초,최근 출연 영화 : '||ms(i).movietitle||'['||ms(i).movieyear||'년]');
                            else
                            dbms_output.put_line('             최초 출연 영화 : '||ms(i).movietitle||'['||ms(i).movieyear||'년]');
                            end if;
                         elsif i = ms.count then
                         dbms_output.put_line('             최근 출연 영화 : '||ms(i).movietitle||'['||ms(i).movieyear||'년]');
                         end if;
                         end loop;
                end if;
            end loop;
        else
                dbms_output.put_line('   배우경력 : 해당없음');
        end if;
         
    end loop;
end;