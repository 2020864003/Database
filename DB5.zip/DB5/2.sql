declare 
    type m_ty is table of starsin%rowtype;
    mv   m_ty;
      cursor ms_csr is select * from moviestar where name in (select name
                                                            from starsin,moviestar
                                                            where name = starname)order by name asc;
    cursor s_csr(sname moviestar.name%type)
    is select * from starsin where sname = starname and starname in (select name
                                                            from starsin,moviestar
                                                            where name = starname)  order by starname,movieyear asc;
    cnt integer;
begin
    for ms in ms_csr loop
        
        select count(distinct movietitle) into cnt
        from  starsin
        where starname = ms.name
        order by starname asc;
        
        if cnt >= 1 then
        dbms_output.put('[' || ms_csr%rowcount || '] ' || ms.name || ': ');
        end if;
        mv := m_ty();
        for s in s_csr(ms.name) loop
           mv.extend;
           mv(s_csr%rowcount) := s;
        end loop;
      
            for i in mv.first..mv.last loop
              
              if mv.count = 1 then
                dbms_output.put_line(mv(i).movietitle||'('||mv(i).movieyear||'년) '||mv.count||'편에 출연');
                else
                    if mv.count = i then
                        dbms_output.put_line(mv(i).movietitle||'('||mv(i).movieyear||'년) 등의 '||mv.count||'편에 출연');
                    else
                         dbms_output.put(mv(i).movietitle||'('||mv(i).movieyear||'년), ');
                    end if;
                end if;
            end loop;      
    end loop;
end;