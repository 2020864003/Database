declare 
    type s_ty is table of studio%rowtype;
    stu   s_ty;
    cursor p_csr is select * from movieexec where certno in(select producerno from movie)order by name asc;
    cursor s_csr(cno movieexec.certno%type) 
                is select * from studio where presno  = cno;

begin
    for p in p_csr loop
        dbms_output.put('[' || p_csr%rowcount || ']제작자 ' || p.name || '는 ');
        stu := s_ty();
        for s in s_csr(p.certno) loop
           stu.extend;
           stu(s_csr%rowcount) := s;
      end loop;
        if stu.count = 0 then
            dbms_output.put_line('영화사를 운영하지 않는다');
              
        else 
            for i in stu.first..stu.last loop
                if stu.count = i then
                    dbms_output.put(stu(i).name);
                    else
                         dbms_output.put(stu(i).name||',');
                end if;
            end loop;
            dbms_output.put_line('을 운영한다.');
        end if;
       
    end loop;
end;