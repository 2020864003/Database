create or replace trigger StarPlays_Trigger
instead of insert on StarPlays
for each row
declare
    max_cnt integer;
    add     moviestar.address%type;
    gen     moviestar.gender%type;
    birth   moviestar.birthdate%type;
    p_no    movie.producerno%type;
    chk integer;
begin
    select count(*) into chk from movie 
    where title = :new.title and year = :new.year;
      select max(c) into max_cnt
       from(select count(*)  c
         from movie 
         group by producerno order by 1
       );
        select me.certno into p_no
        from movieexec me,(select producerno 
                            from (select producerno
                                    from (select count(*) c, producerno
                                          from movie
                                          group by producerno)
                                    where c = max_cnt  order by dbms_Random.value)
                            where rownum = 1) a 
        where me.certno = a.producerno ;
    
    if chk = 0 then
        insert into movie(title,year) values (:new.title,:new.year);
        insert into starsin(movietitle,movieyear,starname) 
        values (:new.title,:new.year,:new.name);
        update movie
        set producerno = p_no
        where title = :new.title and year = :new.year;
        
    end if;

    select address into add
    from (select address , name 
          from moviestar 
          order by dbms_random.value)
    where rownum =1;
    
    select gender into gen
    from(select max(birthdate) , name , gender 
        from moviestar
        group by name,gender
        order by 1 desc)
    where rownum = 1;
    
    select birthdate into birth 
    from(select birthdate 
         from moviestar
         where birthdate > '1970-01-01'
         order by dbms_random.value)
    where rownum = 1;
    
    select count(*) into chk from moviestar
    where name = :new.name;
    if chk = 0 then
        insert into moviestar(name,address,gender,birthdate) 
        values (:new.name,add,gen,birth);
        insert into starsin(movietitle,movieyear,starname) 
        values (:new.title,:new.year,:new.name);
    end if;
end;
