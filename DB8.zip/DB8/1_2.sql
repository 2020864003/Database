create or replace trigger Movieexec_Isert
before insert on movieexec
for each row
declare
    min_cnt     integer;
    cnt   integer;
    chk integer;

begin
    select count(*) into chk from movieexec where certno = :new.certno;
    if chk = 1 or :new.certno is null then
        select max(certno) into cnt from movieexec;
        :new.certno := cnt + 1;
        end if;
        
    if :new.name is null then
        select count(*) into cnt from movieexec;
        :new.name := 'TEMP_'||cnt;
    end if;
    
    if :new.address is null then
        select address into :new.address 
        from (select address from moviestar  where gender = 'male' 
        order by dbms_random.value)
        where rownum = 1 ;
    end if;
    
    if :new.networth is null then
        select min(c) into min_cnt
        from(select count(*)  c
             from movie 
             group by studioname order by 1);
         
        select me.networth into :new.networth
        from movieexec me,(select studioname 
                           from (select studioname
                                 from (select count(*) c, studioname
                                       from movie
                                       group by studioname)
                                 where c = min_cnt  
                                 order by dbms_Random.value)
                           where rownum = 1) a , studio st
        where st.name = a.studioname and st.presno = me.certno ;
    end if;
end;