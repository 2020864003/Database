create or replace procedure get_starinfo(star_name in out starsin.starname%type
     ,cnt out integer,average in out float)
is
begin
    
    select  count(*) , avg(length) into cnt,average
    from movie,starsin 
    where title = movietitle and year = movieyear and starname = star_name
    group by starname;

exception
    when others then
       average := -1;
       cnt := -1;
end;