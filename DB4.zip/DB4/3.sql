declare
   type ar_ty is record(
        nn   studio.name%type,
        aa   studio.address%type,
        mm   movieexec.name%type,
        xx   movieexec.address%type
    );
    
    abc_ty ar_ty;
  type arr_ty is table of abc_ty%type index by varchar2(200); 
  s_arr arr_ty;
  i varchar2(200);
  j integer := 1;
  cursor csr is  
    select st.name as nn , st.address as aa, me.name as mm, me.address as xx
    from studio st,movieexec me
    where presno = certno
    order by 1 desc;

begin

    for s in csr loop
        s_arr(s.nn||s.aa||s.mm||s.xx) := s;
      
    end loop;
 
    i :=s_arr.first;
    while i is not null loop
      dbms_output.put_line(rpad('['||j||']',5)||rpad(s_arr(i).nn,30)||rpad(s_arr(i).aa,60)||rpad(s_arr(i).mm,20) || rpad(s_arr(i).xx,30));
      i := s_arr.next(i);
      j := j+1;
    end loop;
  
end;