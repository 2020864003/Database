-- 생성자 Oracle SQL Developer Data Modeler 22.2.0.165.1149
--   위치:        2022-10-09 23:58:16 KST
--   사이트:      Oracle Database 12cR2
--   유형:      Oracle Database 12cR2



DROP VIEW Dept_Info CASCADE CONSTRAINTS 
;

DROP VIEW Prof_of_CS CASCADE CONSTRAINTS 
;

DROP VIEW Special_Lectures CASCADE CONSTRAINTS 
;

DROP TABLE assiatant CASCADE CONSTRAINTS;

DROP TABLE department CASCADE CONSTRAINTS;

DROP TABLE headprofessor CASCADE CONSTRAINTS;

DROP TABLE learn CASCADE CONSTRAINTS;

DROP TABLE lecture CASCADE CONSTRAINTS;

DROP TABLE lecture_time CASCADE CONSTRAINTS;

DROP TABLE professor CASCADE CONSTRAINTS;

DROP TABLE responsibility CASCADE CONSTRAINTS;

DROP TABLE room CASCADE CONSTRAINTS;

DROP TABLE student CASCADE CONSTRAINTS;

DROP TABLE subject CASCADE CONSTRAINTS;

DROP TABLE time CASCADE CONSTRAINTS;

CREATE OR REPLACE TYPE callno_info AS OBJECT (
    phoneno     CHAR(13),
    homeno      CHAR(13),
    workplaceno CHAR(13)
) NOT FINAL;
/

-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

CREATE OR REPLACE TYPE universitypeople_info AS OBJECT (
    name         CHAR(100),
    home_address VARCHAR2(255),
    callno       callno_info
) NOT FINAL;
/

-- predefined type, no DDL - XMLTYPE

CREATE TABLE assiatant (
    ano               NUMBER(5) NOT NULL,
    info              universitypeople_info,
    belong_department CHAR(100) NOT NULL
);

ALTER TABLE assiatant
    ADD CHECK ( info.callno.phoneno LIKE '010-____-____' );

ALTER TABLE assiatant
    ADD CHECK ( info.callno.homeno LIKE '031-____-____' );

ALTER TABLE assiatant
    ADD CHECK ( info.callno.workplaceno LIKE '031-____-____' );

ALTER TABLE assiatant ADD CONSTRAINT assiatant_pk PRIMARY KEY ( ano );

CREATE TABLE department (
    dname CHAR(100) NOT NULL
);

ALTER TABLE department ADD CONSTRAINT department_pk PRIMARY KEY ( dname );

CREATE TABLE headprofessor (
    headno NUMBER(5) NOT NULL,
    dname  CHAR(100) NOT NULL
);

CREATE UNIQUE INDEX headprofessor__idx ON
    headprofessor (
        dname
    ASC );

ALTER TABLE headprofessor ADD CONSTRAINT headprofessor_pk PRIMARY KEY ( headno );

CREATE TABLE learn (
    learn_stid  NUMBER(15) NOT NULL,
    laern_sname CHAR(100) NOT NULL
);

ALTER TABLE learn ADD CONSTRAINT learn_pk PRIMARY KEY ( learn_stid,
                                                        laern_sname );

CREATE TABLE lecture (
    sname        CHAR(100) NOT NULL,
    roomno       NUMBER(3) NOT NULL,
    bname        CHAR(100) NOT NULL,
    professor_no NUMBER(5) NOT NULL
);

ALTER TABLE lecture ADD CONSTRAINT lecture_pk PRIMARY KEY ( sname );

CREATE TABLE lecture_time (
    l_time NUMBER(2) NOT NULL,
    l_date CHAR(3) NOT NULL
);

ALTER TABLE lecture_time ADD CHECK ( l_time BETWEEN 1 AND 10 );

ALTER TABLE lecture_time
    ADD CHECK ( l_date IN ( '금', '목', '수', '월', '일',
                            '토', '화' ) );

ALTER TABLE lecture_time ADD CONSTRAINT lecture_time_pk PRIMARY KEY ( l_time,
                                                                      l_date );

CREATE TABLE professor (
    prono      NUMBER(5) NOT NULL,
    office     CHAR(100),
    info       universitypeople_info,
    department CHAR(100) NOT NULL
);

ALTER TABLE professor
    ADD CHECK ( info.callno.phoneno LIKE '010-____-____' );

ALTER TABLE professor
    ADD CHECK ( info.callno.homeno LIKE '031-____-____' );

ALTER TABLE professor
    ADD CHECK ( info.callno.workplaceno LIKE '031-____-____' );

ALTER TABLE professor ADD CONSTRAINT professor_pk PRIMARY KEY ( prono );

CREATE TABLE responsibility (
    professor_prono NUMBER(5) NOT NULL,
    subject_name    CHAR(100) NOT NULL
);

ALTER TABLE responsibility ADD CONSTRAINT responsibility_pk PRIMARY KEY ( professor_prono,
                                                                          subject_name );

CREATE TABLE room (
    rno            NUMBER(3) NOT NULL,
    buildingname   CHAR(100) NOT NULL,
    floor          NUMBER(1),
    maximum_people NUMBER(2)
);

ALTER TABLE room ADD CHECK ( floor BETWEEN 1 AND 10 );

ALTER TABLE room ADD CHECK ( maximum_people BETWEEN 0 AND 40 );

ALTER TABLE room ADD CONSTRAINT room_pk PRIMARY KEY ( rno,
                                                      buildingname );

CREATE TABLE student (
    idno          NUMBER(15) NOT NULL,
    faculty       CHAR(100),
    info          universitypeople_info,
    department    CHAR(100) NOT NULL,
    subdepartment CHAR(100)
);

ALTER TABLE student
    ADD CHECK ( info.callno.phoneno LIKE '010-____-____' );

ALTER TABLE student
    ADD CHECK ( info.callno.homeno LIKE '031-____-____' );

ALTER TABLE student
    ADD CHECK ( info.callno.workplaceno LIKE '031-____-____' );

ALTER TABLE student ADD CONSTRAINT student_pk PRIMARY KEY ( idno );

CREATE TABLE subject (
    name        CHAR(100) NOT NULL,
    grades      NUMBER(1),
    assistantno NUMBER(5) NOT NULL
);

ALTER TABLE subject
    ADD CHECK ( grades IN ( 1, 2, 3 ) );

ALTER TABLE subject ADD CONSTRAINT subject_pk PRIMARY KEY ( name );

CREATE TABLE time (
    teaching_time  NUMBER(2) NOT NULL,
    taeching_date  CHAR(3) NOT NULL,
    teaching_lname CHAR(100) NOT NULL
);

ALTER TABLE time ADD CHECK ( teaching_time BETWEEN 1 AND 10 );

ALTER TABLE time
    ADD CHECK ( taeching_date IN ( '금', '목', '수', '월', '일',
                                   '토', '화' ) );

ALTER TABLE time
    ADD CONSTRAINT time_pk PRIMARY KEY ( teaching_time,
                                         taeching_date,
                                         teaching_lname );

ALTER TABLE subject
    ADD CONSTRAINT assistant_to_subject FOREIGN KEY ( assistantno )
        REFERENCES assiatant ( ano );

ALTER TABLE student
    ADD CONSTRAINT belong FOREIGN KEY ( department )
        REFERENCES department ( dname );

ALTER TABLE assiatant
    ADD CONSTRAINT belong_assistant FOREIGN KEY ( belong_department )
        REFERENCES department ( dname );

ALTER TABLE professor
    ADD CONSTRAINT belong_professor FOREIGN KEY ( department )
        REFERENCES department ( dname );

ALTER TABLE headprofessor
    ADD CONSTRAINT head_department FOREIGN KEY ( dname )
        REFERENCES department ( dname );

ALTER TABLE learn
    ADD CONSTRAINT learn_lecture_fk FOREIGN KEY ( laern_sname )
        REFERENCES lecture ( sname );

ALTER TABLE learn
    ADD CONSTRAINT learn_student_fk FOREIGN KEY ( learn_stid )
        REFERENCES student ( idno );

ALTER TABLE lecture
    ADD CONSTRAINT learning_room FOREIGN KEY ( roomno,
                                               bname )
        REFERENCES room ( rno,
                          buildingname );

ALTER TABLE headprofessor
    ADD CONSTRAINT professor_head FOREIGN KEY ( headno )
        REFERENCES professor ( prono );

ALTER TABLE responsibility
    ADD CONSTRAINT responsibility_professor_fk FOREIGN KEY ( professor_prono )
        REFERENCES professor ( prono );

ALTER TABLE responsibility
    ADD CONSTRAINT responsibility_subject_fk FOREIGN KEY ( subject_name )
        REFERENCES subject ( name );

ALTER TABLE lecture
    ADD CONSTRAINT s_to_l FOREIGN KEY ( sname )
        REFERENCES subject ( name );

ALTER TABLE student
    ADD CONSTRAINT sub_department FOREIGN KEY ( subdepartment )
        REFERENCES department ( dname );

ALTER TABLE lecture
    ADD CONSTRAINT teach FOREIGN KEY ( professor_no )
        REFERENCES professor ( prono );

ALTER TABLE time
    ADD CONSTRAINT time_lecture_fk FOREIGN KEY ( teaching_lname )
        REFERENCES lecture ( sname );

ALTER TABLE time
    ADD CONSTRAINT time_lecture_time_fk FOREIGN KEY ( teaching_time,
                                                      taeching_date )
        REFERENCES lecture_time ( l_time,
                                  l_date );

CREATE OR REPLACE VIEW Dept_Info ( 학과명, "교수 수", "조교 수" ) AS
SELECT
    department.dname AS 학과명,
    COUNT(*)         AS "교수 수",
    COUNT(*)         AS "조교 수"
FROM
    professor,
    department,
    assiatant
WHERE
        department.dname = professor.department
    AND department.dname = assiatant.belong_department
GROUP BY
    department.dname 
;

CREATE OR REPLACE VIEW Prof_of_CS ( 이름, 사무실, 강의수 ) AS
SELECT
    professor."Info"."name" AS 이름,
    professor.office        AS 사무실,
    COUNT(*)                AS 강의수
FROM
         professor
    INNER JOIN lecture ON professor.prono = lecture.professor_no
WHERE
    professor.department = '소프트웨어학과'
GROUP BY
    professor."Info"."name",
    professor.office,
    professor.department 
;

CREATE OR REPLACE VIEW Special_Lectures ( 강의명, 건물명, 호실, 요일, 교시 ) AS
SELECT
    lecture.sname   AS 강의명,
    lecture.bname   AS 건물명,
    lecture.roomno  AS 호실,
    time.learn_date AS 요일,
    time.learn_time AS 교시
FROM
    lecture,
    time
WHERE
        lecture.sname = time.sname
    AND time.learn_date = '월'
    AND time.learn_date = '수'
    AND time.learn_date = '금'
    AND time.learn_time > 6
    AND time.learn_time < 9 
;



-- Oracle SQL Developer Data Modeler 요약 보고서: 
-- 
-- CREATE TABLE                            12
-- CREATE INDEX                             1
-- ALTER TABLE                             44
-- CREATE VIEW                              3
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   2
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
