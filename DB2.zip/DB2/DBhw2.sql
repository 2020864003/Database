-- 생성자 Oracle SQL Developer Data Modeler 22.2.0.165.1149
--   위치:        2022-10-02 19:01:28 KST
--   사이트:      Oracle Database 12cR2
--   유형:      Oracle Database 12cR2



DROP TABLE answer CASCADE CONSTRAINTS;

DROP TABLE comapny CASCADE CONSTRAINTS;

DROP TABLE company_made CASCADE CONSTRAINTS;

DROP TABLE employee CASCADE CONSTRAINTS;

DROP TABLE goods CASCADE CONSTRAINTS;

DROP TABLE goods_order CASCADE CONSTRAINTS;

DROP TABLE goods_posting CASCADE CONSTRAINTS;

DROP TABLE "Order" CASCADE CONSTRAINTS;

DROP TABLE posting CASCADE CONSTRAINTS;

DROP TABLE shipping_posting CASCADE CONSTRAINTS;

DROP TABLE "User" CASCADE CONSTRAINTS;

-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE answer (
    title        CHAR(30) NOT NULL,
    posting_date DATE NOT NULL,
    manager_no   NUMBER(8) NOT NULL
);

ALTER TABLE answer
    ADD CHECK ( posting_date BETWEEN DATE '2022-01-01' AND DATE '2022-12-31' );

CREATE UNIQUE INDEX answer__idx ON
    answer (
        title
    ASC,
        posting_date
    ASC );

ALTER TABLE answer
    ADD CONSTRAINT answer_pk PRIMARY KEY ( title,
                                           posting_date,
                                           manager_no );

CREATE TABLE comapny (
    name    CHAR(30) NOT NULL,
    pno     NUMBER(13),
    address VARCHAR2(255)
);

ALTER TABLE comapny ADD CHECK ( pno LIKE '010-____-____' );

ALTER TABLE comapny ADD CONSTRAINT comapny_pk PRIMARY KEY ( name );

CREATE TABLE company_made (
    c_name   CHAR(30) NOT NULL,
    goods_no NUMBER(8) NOT NULL
);

ALTER TABLE company_made ADD CONSTRAINT relation_5_pk PRIMARY KEY ( c_name,
                                                                    goods_no );

CREATE TABLE employee (
    emp_no     NUMBER(8) NOT NULL,
    nickname   CHAR(50) NOT NULL,
    name       CHAR(30),
    pno        NUMBER(13),
    address    VARCHAR2(255),
    email      CHAR(20),
    department CHAR(30) NOT NULL
);

ALTER TABLE employee ADD CHECK ( pno LIKE '010-____-____' );

ALTER TABLE employee ADD CHECK ( email LIKE '__________@_____.com' );

CREATE UNIQUE INDEX employee__idx ON
    employee (
        department
    ASC );

ALTER TABLE employee ADD CONSTRAINT employee_pk PRIMARY KEY ( emp_no );

ALTER TABLE employee ADD CONSTRAINT management UNIQUE ( nickname );

CREATE TABLE goods (
    g_no  NUMBER(8) NOT NULL,
    name  CHAR(30) NOT NULL,
    count NUMBER(8),
    price NUMBER(7)
);

ALTER TABLE goods ADD CHECK ( price BETWEEN 100 AND 900000 );

ALTER TABLE goods ADD CONSTRAINT goods_pk PRIMARY KEY ( g_no );

CREATE TABLE goods_order (
    order_goods CHAR(50) NOT NULL,
    goods_no    NUMBER(8) NOT NULL
);

ALTER TABLE goods_order ADD CONSTRAINT goods_order_pk PRIMARY KEY ( order_goods,
                                                                    goods_no );

CREATE TABLE goods_posting (
    goods_title        CHAR(30) NOT NULL,
    goods_posting_date DATE NOT NULL,
    writer             CHAR(30)
);

ALTER TABLE goods_posting
    ADD CHECK ( goods_posting_date BETWEEN DATE '2022-01-01' AND DATE '2022-12-31' );

ALTER TABLE goods_posting ADD CONSTRAINT order_posting_pk PRIMARY KEY ( goods_title,
                                                                        goods_posting_date );

CREATE TABLE "Order" (
    goods                    CHAR(50) NOT NULL,
    order_date               DATE NOT NULL,
    shipping_address_choice1 VARCHAR2(255),
    shipping_address_choice2 VARCHAR2(255)
);

ALTER TABLE "Order"
    ADD CHECK ( order_date BETWEEN DATE '2022-01-01' AND DATE '2022-12-31' );

ALTER TABLE "Order" ADD CONSTRAINT order_pk PRIMARY KEY ( goods );

CREATE TABLE posting (
    title        CHAR(30) NOT NULL,
    posting_date DATE NOT NULL,
    context      VARCHAR2(255),
    manager      CHAR(50)
);

ALTER TABLE posting
    ADD CHECK ( posting_date BETWEEN DATE '2022-01-01' AND DATE '2022-12-31' );

ALTER TABLE posting ADD CONSTRAINT posting_pk PRIMARY KEY ( title,
                                                            posting_date );

CREATE TABLE shipping_posting (
    shipping_title    CHAR(30) NOT NULL,
    ship_posting_date DATE NOT NULL,
    writer            CHAR(30)
);

ALTER TABLE shipping_posting
    ADD CHECK ( ship_posting_date BETWEEN DATE '2022-01-01' AND DATE '2022-12-31' );

ALTER TABLE shipping_posting ADD CONSTRAINT shipping_posting_pk PRIMARY KEY ( shipping_title,
                                                                              ship_posting_date );

CREATE TABLE "User" (
    nickname     CHAR(30) NOT NULL,
    home_address VARCHAR2(255) NOT NULL,
    home_pno     NUMBER(13) NOT NULL,
    email        CHAR(20) NOT NULL,
    work_address VARCHAR2(255) NOT NULL,
    name         CHAR(30),
    work_pno     NUMBER(12)
);

ALTER TABLE "User" ADD CHECK ( home_pno LIKE '010-____-____' );

ALTER TABLE "User" ADD CHECK ( email LIKE '__________@_____.com' );

ALTER TABLE "User" ADD CHECK ( work_pno LIKE '051-___-____' );

ALTER TABLE "User" ADD CONSTRAINT user_pk PRIMARY KEY ( nickname );

ALTER TABLE "User" ADD CONSTRAINT "Unique" UNIQUE ( home_address );

ALTER TABLE answer
    ADD CONSTRAINT answer_to_posting FOREIGN KEY ( title,
                                                   posting_date )
        REFERENCES posting ( title,
                             posting_date );

ALTER TABLE posting
    ADD CONSTRAINT e_answer FOREIGN KEY ( manager )
        REFERENCES employee ( nickname );

ALTER TABLE answer
    ADD CONSTRAINT e_answerv1 FOREIGN KEY ( manager_no )
        REFERENCES employee ( emp_no );

ALTER TABLE employee
    ADD CONSTRAINT em_to_comapany FOREIGN KEY ( department )
        REFERENCES comapny ( name );

ALTER TABLE goods_order
    ADD CONSTRAINT goods_order_goods_fk FOREIGN KEY ( goods_no )
        REFERENCES goods ( g_no );

ALTER TABLE goods_order
    ADD CONSTRAINT goods_order_order_fk FOREIGN KEY ( order_goods )
        REFERENCES "Order" ( goods );

ALTER TABLE shipping_posting
    ADD CONSTRAINT posting_to_shipping FOREIGN KEY ( shipping_title,
                                                     ship_posting_date )
        REFERENCES posting ( title,
                             posting_date );

ALTER TABLE goods_posting
    ADD CONSTRAINT poting_to_goods FOREIGN KEY ( goods_title,
                                                 goods_posting_date )
        REFERENCES posting ( title,
                             posting_date );

ALTER TABLE company_made
    ADD CONSTRAINT relation_5_comapny_fk FOREIGN KEY ( c_name )
        REFERENCES comapny ( name );

ALTER TABLE company_made
    ADD CONSTRAINT relation_5_goods_fk FOREIGN KEY ( goods_no )
        REFERENCES goods ( g_no );

ALTER TABLE "Order"
    ADD CONSTRAINT user_buy FOREIGN KEY ( shipping_address_choice1 )
        REFERENCES "User" ( home_address );

ALTER TABLE goods_posting
    ADD CONSTRAINT user_goods_posting FOREIGN KEY ( writer )
        REFERENCES "User" ( nickname );

ALTER TABLE shipping_posting
    ADD CONSTRAINT user_shipping_posting FOREIGN KEY ( writer )
        REFERENCES "User" ( nickname );



-- Oracle SQL Developer Data Modeler 요약 보고서: 
-- 
-- CREATE TABLE                            11
-- CREATE INDEX                             2
-- ALTER TABLE                             38
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
