---department
Insert into department (dName) values ('소프트웨어학과');
Insert into department (dName) values ('토목공학과');
Insert into department (dName) values ('기계공학과');
---professor
Insert into professor (prono, department, office, Info) 
values (1,'소프트웨어학과','8관',universitypeople_info('홍석희','부산시 남구',callNo_Info('010-5546-8953','031-6657-9995','031-5521-6957')));
Insert into professor (prono, department, office, Info) 
values (2,'소프트웨어학과','8관',universitypeople_info('변석우','부산시 수영',callNo_Info('010-6654-2253','031-1475-7541','031-6632-6957')));
Insert into professor (prono, department, office, Info) 
values (3,'소프트웨어학과','8관',universitypeople_info('강인수','부산시 연산',callNo_Info('010-1449-8978','031-1122-6322','031-4412-6957')));
Insert into professor (prono, department, office, Info) 
values (4,'토목공학과','7관',universitypeople_info('김철수','부산시 해운대',callNo_Info('010-4452-3297','031-6542-7644','031-1326-1015')));
Insert into professor (prono, department, office, Info) 
values (5,'기계공학과','4관',universitypeople_info('김길수','부산시 서면',callNo_Info('010-1588-7751','031-3365-7895','031-7855-3325')));
---headprofessor
Insert into headprofessor (HeadNo,dname) values (1,'소프트웨어학과');
Insert into headprofessor (HeadNo,dName) values (4,'토목공학과');
Insert into headprofessor (HeadNo,dName) values (5,'기계공학과');
---student
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875063,'학부','소프트웨어학과','토목공학과'
,universitypeople_info('정유엽','부산시 남구',callNo_Info('010-6613-5303','031-9984-5303','031-9956-5562')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875020,'학부','소프트웨어학과','토목공학과'
,universitypeople_info('김태현','부산시 남구',callNo_Info('010-6783-4563','031-1124-5263','031-9944-7852')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875001,'학부','소프트웨어학과',null
,universitypeople_info('강동현','부산시 남구',callNo_Info('010-6775-5123','031-9564-5623','031-9126-1124')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875021,'학부','소프트웨어학과',null
,universitypeople_info('김도균','부산시 수영',callNo_Info('010-4523-7852','031-4464-5533','031-9782-1152')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875062,'학부','소프트웨어학과','기계공학과'
,universitypeople_info('정승훈','부산시 양산',callNo_Info('010-6445-0123','031-7854-4452','031-9923-4562')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875064,'학부','토목공학과','소프트웨어학과'
,universitypeople_info('정진혁','부산시 서면',callNo_Info('010-1233-5404','031-2224-5404','031-1654-5404')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875018,'학부','기계공학과','토목공학과'
,universitypeople_info('김민수','부산시 연산',callNo_Info('010-7783-4563','031-9131-7851','031-4566-1372')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875040,'학부','기계공학과','토목공학과'
,universitypeople_info('이윤호','부산시 사상',callNo_Info('010-4563-1123','031-7884-4453','031-4956-5512')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2015875056,'석사','토목공학과','소프트웨어학과'
,universitypeople_info('박세준','부산시 다대포',callNo_Info('010-6613-5303','031-9984-5235','031-7866-5562')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875053,'박사','소프트웨어학과',null
,universitypeople_info('장해웅','부산시 광안',callNo_Info('010-6443-5223','031-7851-5456','031-7226-5042')));

Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875010,'박사','소프트웨어학과','토목공학과'
,universitypeople_info('김범수','부산시 수영',callNo_Info('010-6453-5773','031-7821-5490','031-7766-5082')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875016,'박사','소프트웨어학과','기계공학과'
,universitypeople_info('나 얼','부산시 남구',callNo_Info('010-6231-3333','031-2413-3333','031-7542-3333')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875073,'박사','소프트웨어학과','기계공학과'
,universitypeople_info('박효신','부산시 서면',callNo_Info('010-6213-5444','031-7841-5444','031-7267-5444')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875077,'박사','소프트웨어학과','기계공학과'
,universitypeople_info('이순신','부산시 연산',callNo_Info('010-6415-5113','031-1515-2929','031-5521-8181')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875045,'박사','소프트웨어학과','기계공학과'
,universitypeople_info('문상훈','부산시 광안',callNo_Info('010-6643-4413','031-7851-5456','031-7226-5042')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875024,'박사','소프트웨어학과','토목공학과'
,universitypeople_info('김상훈','부산시 수영',callNo_Info('010-6499-9999','031-7851-9999','031-7226-9999')));
Insert into student (IDNo,faculty,department,subdepartment,info) values (2018875038,'박사','소프트웨어학과','토목공학과'
,universitypeople_info('이대호','부산시 남구',callNo_Info('010-6443-1414','031-7851-1414','031-7226-1414')));



---assiatant
Insert into assiatant (aNo,belong_department,Info) values (1,'소프트웨어학과'
,universitypeople_info('김강산','부산시 서면',callNo_Info('010-1488-7251','031-3765-7195','031-7465-3785')));
Insert into assiatant (aNo,belong_department,Info) values (2,'소프트웨어학과'
,universitypeople_info('강백호','부산시 수영',callNo_Info('010-8858-7157','031-4669-2395','031-8765-8888')));
Insert into assiatant (aNo,belong_department,Info) values (3,'소프트웨어학과'
,universitypeople_info('이해민','부산시 수영',callNo_Info('010-1126-1258','031-4949-6632','031-6615-8738')));
Insert into assiatant (aNo,belong_department,Info) values (4,'토목공학과'
,universitypeople_info('김우빈','부산시 남구',callNo_Info('010-8664-3589','031-4779-2395','031-8765-8103')));
Insert into assiatant (aNo,belong_department,Info) values (5,'기계공학과'
,universitypeople_info('정 민','부산시 민락',callNo_Info('010-8778-4157','031-3365-3555','031-8775-1778')));
Insert into assiatant (aNo,belong_department,Info) values (6,'토목공학과'
,universitypeople_info('정상구','부산시 수영',callNo_Info('010-1254-3596','031-6045-2395','031-1156-8823')));
Insert into assiatant (aNo,belong_department,Info) values (7,'기계공학과'
,universitypeople_info('이영주','부산시 해운대',callNo_Info('010-8123-7157','031-1129-2795','031-4625-8156')));
---subject
Insert into subject (name,grades,assistantNo) values ('모바일프로그래밍',3,1);
Insert into subject (name,grades,assistantNo) values ('프로그래밍언어론',3,2);
Insert into subject (name,grades,assistantNo) values ('데이터베이스응용',1,3);
Insert into subject (name,grades,assistantNo) values ('토목정의론',3,4);
Insert into subject (name,grades,assistantNo) values ('토목공학기초',2,6);
Insert into subject (name,grades,assistantNo) values ('기계의 이해',3,5);
Insert into subject (name,grades,assistantNo) values ('기계론',2,7);
---responsibility
Insert into responsibility (professor_ProNo,Subject_name) values (2,'프로그래밍언어론');
Insert into responsibility (professor_ProNo,Subject_name) values (3,'모바일프로그래밍');
Insert into responsibility (professor_ProNo,Subject_name) values (1,'데이터베이스응용');
Insert into responsibility (professor_ProNo,Subject_name) values (4,'토목정의론');
Insert into responsibility (professor_ProNo,Subject_name) values (4,'토목공학기초');
Insert into responsibility (professor_ProNo,Subject_name) values (5,'기계의 이해');
Insert into responsibility (professor_ProNo,Subject_name) values (5,'기계론');
---Lecture_Time

Insert into Lecture_Time (L_Time,L_date) values (1,'월');
Insert into Lecture_Time (L_Time,L_date) values (2,'월');
Insert into Lecture_Time (L_Time,L_date) values (3,'월');

Insert into Lecture_Time (L_Time,L_date) values (7,'월');
Insert into Lecture_Time (L_Time,L_date) values (8,'월');
Insert into Lecture_Time (L_Time,L_date) values (9,'월');


Insert into Lecture_Time (L_Time,L_date) values (1,'화');
Insert into Lecture_Time (L_Time,L_date) values (2,'화');
Insert into Lecture_Time (L_Time,L_date) values (3,'화');
Insert into Lecture_Time (L_Time,L_date) values (4,'화');
Insert into Lecture_Time (L_Time,L_date) values (5,'화');
Insert into Lecture_Time (L_Time,L_date) values (6,'화');

Insert into Lecture_Time (L_Time,L_date) values (2,'수');
Insert into Lecture_Time (L_Time,L_date) values (3,'수');
Insert into Lecture_Time (L_Time,L_date) values (6,'수');
Insert into Lecture_Time (L_Time,L_date) values (7,'수');
Insert into Lecture_Time (L_Time,L_date) values (8,'수');


Insert into Lecture_Time (L_Time,L_date) values (2,'목');
Insert into Lecture_Time (L_Time,L_date) values (3,'목');
Insert into Lecture_Time (L_Time,L_date) values (4,'목');
Insert into Lecture_Time (L_Time,L_date) values (5,'목');
Insert into Lecture_Time (L_Time,L_date) values (6,'목');
Insert into Lecture_Time (L_Time,L_date) values (7,'목');

Insert into Lecture_Time (L_Time,L_date) values (6,'금');
Insert into Lecture_Time (L_Time,L_date) values (7,'금');
Insert into Lecture_Time (L_Time,L_date) values (8,'금');

---Room
Insert into Room (rNo,buildingname,floor,Maximum_people) values (628,'2공학관',6,40);
Insert into Room (rNo,buildingname,floor,Maximum_people) values (629,'2공학관',6,40);
Insert into Room (rNo,buildingname,floor,Maximum_people) values (626,'2공학관',6,35);
Insert into Room (rNo,buildingname,floor,Maximum_people) values (564,'1공학관',5,40);
Insert into Room (rNo,buildingname,floor,Maximum_people) values (318,'2공학관',3,25);
Insert into Room (rNo,buildingname,floor,Maximum_people) values (104,'1공학관',1,30);


---Lecture
Insert into Lecture (sName,roomNo,bName,Professor_No) values ('모바일프로그래밍',628,'2공학관',3);
Insert into Lecture (sName,roomNo,bName,Professor_No) values ('데이터베이스응용',628,'2공학관',1);
Insert into Lecture (sName,roomNo,bName,Professor_No) values ('프로그래밍언어론',629,'2공학관',2);
Insert into Lecture (sName,roomNo,bName,Professor_No) values ('토목정의론',564,'1공학관',4);
Insert into Lecture (sName,roomNo,bName,Professor_No) values ('토목공학기초',318,'2공학관',4);
Insert into Lecture (sName,roomNo,bName,Professor_No) values ('기계의 이해',104,'1공학관',5);
Insert into Lecture (sName,roomNo,bName,Professor_No) values ('기계론',104,'1공학관',5);

---Time
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (7,'월','프로그래밍언어론');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (8,'월','프로그래밍언어론');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (9,'월','프로그래밍언어론');

Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (1,'월','기계론');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (2,'월','기계론');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (3,'월','기계론');

Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (4,'화','모바일프로그래밍');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (5,'화','모바일프로그래밍');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (6,'화','모바일프로그래밍');

Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (1,'화','기계의 이해');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (2,'화','기계의 이해');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (3,'화','기계의 이해');

Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (2,'수','토목공학기초');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (3,'수','토목공학기초');

Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (6,'수','데이터베이스응용');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (7,'수','데이터베이스응용');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (8,'수','데이터베이스응용');

Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (2,'목','모바일프로그래밍');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (3,'목','모바일프로그래밍');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (4,'목','모바일프로그래밍');

Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (5,'목','토목정의론');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (6,'목','토목정의론');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (7,'목','토목정의론');

Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (6,'금','프로그래밍언어론');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (7,'금','프로그래밍언어론');
Insert into Time (TEACHING_TIME,TAECHING_DATE,TEACHING_LNAME) values (8,'금','프로그래밍언어론');

---Learn
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('모바일프로그래밍',2018875021);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('모바일프로그래밍',2018875062);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('모바일프로그래밍',2018875064);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('모바일프로그래밍',2018875016);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('모바일프로그래밍',2018875073);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('모바일프로그래밍',2018875077);

Insert into Learn (LAERN_SNAME,LEARN_STID) values ('데이터베이스응용',2015875056);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('데이터베이스응용',2018875053);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('데이터베이스응용',2018875010);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('데이터베이스응용',2018875045);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('데이터베이스응용',2018875038);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('데이터베이스응용',2018875024);

Insert into Learn (LAERN_SNAME,LEARN_STID) values ('프로그래밍언어론',2018875063);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('프로그래밍언어론',2018875020);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('프로그래밍언어론',2018875001);

Insert into Learn (LAERN_SNAME,LEARN_STID) values ('토목정의론',2018875063);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('토목정의론',2018875020);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('토목정의론',2018875018);

Insert into Learn (LAERN_SNAME,LEARN_STID) values ('토목공학기초',2018875040);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('토목공학기초',2015875056);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('토목공학기초',2018875010);

Insert into Learn (LAERN_SNAME,LEARN_STID) values ('기계의 이해',2018875016);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('기계의 이해',2018875073);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('기계의 이해',2018875077);

Insert into Learn (LAERN_SNAME,LEARN_STID) values ('기계론',2018875062);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('기계론',2018875018);
Insert into Learn (LAERN_SNAME,LEARN_STID) values ('기계론',2018875040);


