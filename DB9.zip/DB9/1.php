<?php
// for correct error message outputs
//putenv("NLS_LANG=KOREAN_KOREA.AL32UTF8");

$conn = oci_connect("db2018875063","db66135303", "localhost/course");
if (!$conn) {
	$e = oci_error();
	print htmlentities($e['message']);
}
$title = $_GET["title"];
$year = $_GET["year"];
if(!empty($title) & !empty($year)) {
    $where = " and title = '$title' and year = $year ";
} else $where = "";
$stmt = oci_parse($conn,
	"select title, year, length, e1.name pname, e2.name sname from movie, studio s, movieexec e1 ,movieexec e2".
	" where studioname = s.name and producerno = e1.certno and s.presno = e2.certno $where order by 2 asc, 3 ");
if (!$stmt) {
	$e = oci_error($conn);
	print $e['message'];
	//print htmlentities($e['message']);
}
if (!oci_execute($stmt)) {
	$e = oci_error();
	print htmlentities($e['message']);
}
print "<TABLE bgcolor=#abbcbabc border=1 cellspacing=2>\n";
print "<TR bgcolor=#1ebcbabf align=center><TH> 제목 <TH> 연도 <TH> 상영시간 <TH> 제작자 <th> 영화사사장 <th> 출연배우수 <th> 출연배우진</TR>\n";
while ($row = oci_fetch_array($stmt)) {
    $title = $row['TITLE'];
    $title = str_replace("'", "''", $title);
    $year = $row['YEAR'];
    $ms_cnt = oci_parse($conn,
	"select count(*) from starsin where movietitle = '$title' and movieyear = $year");
    if (!$ms_cnt) {
            $e = oci_error($conn);
            print $e['message'];
            //print htmlentities($e['message']);
    }
    if (!oci_execute($ms_cnt)) {
            $e = oci_error();
            print htmlentities($e['message']);
    }
    $st = oci_parse($conn, 
            "select starname from starsin where  movietitle = '$title' and movieyear = $year");
     if (!$st) {
            $e = oci_error($conn);
            print $e['message'];
            //print htmlentities($e['message']);
    }
    if (!oci_execute($st)) {
            $e = oci_error();
            print htmlentities($e['message']);
    }
    $s = oci_fetch_array($st);
    $mvst =$s[0];
    while($s = oci_fetch_array($st)){
        $mvst = $mvst . ',' . $s[0];
    }
    $r = oci_fetch_array($ms_cnt);
    if($r[0]>0){
    $cnt = $r[0];
        print "<TR> <TD> {$row[0]} <TD> {$row['YEAR']} <TD> {$row['LENGTH']}분 <TD> {$row['PNAME']} <td>".
        " {$row['SNAME']}<td> {$cnt}명 <td> {$mvst}</TR>\n";
    }else {
        $cnt = '정보없음';
        print "<TR> <TD> {$row[0]} <TD> {$row['YEAR']} <TD> {$row['LENGTH']}분 <TD> {$row['PNAME']} <td>".
        " {$row['SNAME']}<td> {$cnt} <td> 정보없음</TR>\n";
    }
}
print "</TABLE>\n";
oci_free_statement($stmt);
oci_close($conn);
?>
