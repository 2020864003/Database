<?php
// for correct error message outputs
//putenv("NLS_LANG=KOREAN_KOREA.AL32UTF8");

$conn = oci_connect("db2018875063","db66135303", "localhost/course");
if (!$conn) {
	$e = oci_error();
	print htmlentities($e['message']);
}

$name = $_GET["name"];
$stmt = oci_parse($conn, "select m.title,m.year,m.length,e.name from movie m,movieexec e,studio s "
        . "where e.certno = m.producerno and s.name = '$name' and s.name = m.studioname");
if (!$stmt) {
	$e = oci_error($conn);
	print $e['message'];
	//print htmlentities($e['message']);
}

if (!oci_execute($stmt)) {
	$e = oci_error();
	print htmlentities($e['message']);
}

print "<TABLE bgcolor=#abbcbabc border=1 cellspacing=2>\n";
print "<TR bgcolor=#1ebcbabf align=center><TH> 제목 <TH> 개봉년도 <TH> 상영시간 <TH> 제작자이름  </TR>\n";

while ($row = oci_fetch_array($stmt)) {
    print "<TR> <TD> {$row[0]} <TD> {$row[1]} <TD> {$row[2]}분 <TD> {$row[3]}</TR>\n";
}
print "</TABLE>\n";

oci_free_statement($stmt);
oci_close($conn);
?>
