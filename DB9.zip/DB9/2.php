<?php
// for correct error message outputs
//putenv("NLS_LANG=KOREAN_KOREA.AL32UTF8");

$conn = oci_connect("db2018875063","db66135303", "localhost/course");
if (!$conn) {
	$e = oci_error();
	print htmlentities($e['message']);
}

$name = $_GET["name"];

if(!empty($name)) {
    $where = " and name = '$name' ";
} else $where = "";


$stmt = oci_parse($conn,
	"select name from  studio ".
	" order by name asc ");
if (!$stmt) {
	$e = oci_error($conn);
	print $e['message'];
	//print htmlentities($e['message']);
}

if (!oci_execute($stmt)) {
	$e = oci_error();
	print htmlentities($e['message']);
}

print "<TABLE bgcolor=#abbcbabc border=1 cellspacing=2>\n";
print "<TR bgcolor=#1ebcbabf align=center><TH> 영화사 <TH> 제작한 영화수 </TR>\n";


while ($row = oci_fetch_array($stmt)) {
    $name = $row['NAME'];
    
    $cnt = oci_parse($conn, "select count(*) from movie where studioname = '$name' ");
    if (!$cnt) {
	$e = oci_error($conn);
	print $e['message'];
	//print htmlentities($e['message']);
    }

    if (!oci_execute($cnt)) {
	$e = oci_error();
	print htmlentities($e['message']);
    }
   $r = oci_fetch_array($cnt);
   $s_cnt = $r[0];
  
   print "<TR> <TD> <a target=_blank href='2_1.php?name=".htmlentities($name, ENT_QUOTES)."'>{$row['NAME']}</a> <TD> "
   . "<a target=_blank href='2_2.php?name=".htmlentities($name, ENT_QUOTES)."'>{$s_cnt}</a>  </TR>\n";
}



print "</TABLE>\n";

oci_free_statement($stmt);
oci_close($conn);
?>
