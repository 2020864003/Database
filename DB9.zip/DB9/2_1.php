<?php
// for correct error message outputs
//putenv("NLS_LANG=KOREAN_KOREA.AL32UTF8");

$conn = oci_connect("db2018875063","db66135303", "localhost/course");
if (!$conn) {
	$e = oci_error();
	print htmlentities($e['message']);
}

$name = $_GET["name"];
$stmt = oci_parse($conn, "select s.name,s.address,e.name,e.address,e.networth from movieexec e,studio s where e.certno = s.presno and s.name = $name");
if (!$stmt) {
	$e = oci_error($conn);
	print $e['message'];
	//print htmlentities($e['message']);
}

if (!oci_execute($stmt)) {
	$e = oci_error();
	print htmlentities($e['message']);
}

print "<TABLE bgcolor=#abbcbabc border=1 cellspacing=2>\n";
print "<TR bgcolor=#1ebcbabf align=center><TH> 영화사 <TH> 주소 <TH> 사장 <TH> 사장의주소 <TH> 재산액수  </TR>\n";

while ($row = oci_fetch_array($stmt)) {
    print "<TR> <TD> {$row[0]} <TD> {$row[1]} <TD> {$row[2]} <TD> {$row[3]} <td>{$row[4]}</TR>\n";
}
print "</TABLE>\n";

oci_free_statement($stmt);
oci_close($conn);
?>
