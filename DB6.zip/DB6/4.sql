declare
    cursor s_csr is select * from studioinfo order by name asc;
    mov studioinfo.movies%type;
    str studioinfo.stars%type;
begin
    for s in s_csr loop
        dbms_output.put_line('['||s_csr%rowcount||']영화사['||s.name||'] : 
            주소['||s.address||'], 사장['||s.president||']');
        mov := s.movies;
        if mov.count >0 then
            for i in mov.first..mov.last loop
                dbms_output.put_line(lpad('-제목 : ',13)||rpad(mov(i).title||'('||
                mov(i).year||')',44)|| '예산 : '||mov(i).budget||', 제작자 : '||mov(i).producer);
            end loop;
           
        else
                dbms_output.put_line(lpad('***** 제작한 영화 없음 ******',41));
        end if;
       str := s.stars;
        if str.count >0 then
            for i in str.first..str.last loop
                dbms_output.put_line(lpad('#소속배우 : ',17)||rpad(str(i).name,25)||', 계약금액 : '||
                str(i).salary||' , 계약기간 : '||str(i).cont_period);
            end loop;
            dbms_output.put_line('');
        else
            dbms_output.put_line(lpad('------ 소속 영화배우 없음 ------',44));
            dbms_output.put_line('');
        end if;
    end loop;
end;