declare
   
    cnt integer;
    
    cursor s_csr is select * from studio;
    cursor me_csr(prs studio.presno%type) is select * from movieexec where prs = certno;
    cursor st_csr is select name sname, r from (select m.* , rownum r from (select *  
            from moviestar m order by dbms_random.value) m)
            where r <= trunc(dbms_random.value(0,cnt/3));
    cursor m_csr(sname studio.name%type) is 
            select title t ,year y ,producerno pro from movie where sname = studioname
            order by t,y asc;
    cursor pr_csr(proNo movie.producerno%type) is select name pro from movieexec 
                                        where certno = proNo;
    type ms_ty is table of moviestar%rowtype;
    ms   ms_ty;
    
    ins_s varchar2(200) := 'insert into studioinfo values (:1,:2,:3,
                        movie_tab(),star_tab())';
    ins_m varchar2(200) := 'insert into 
                    table(select movies from studioinfo where name =:1) 
                    values(mv_ty(:2,:3,:4,:5))';              
    ins_st varchar2(200) := 'insert into 
                        table(select stars from studioinfo where name =:1) 
                        values(star_ty(:2,:3,:4))';
begin
    for s in s_csr loop
        
        select count(*) into cnt
        from moviestar;
        
       
        for me in me_csr(s.presno) loop
            execute immediate ins_s using s.name, s.address, me.name;
        end loop;
        for m in m_csr(s.name) loop
            for p in pr_csr(m.pro) loop
                execute immediate ins_m  using s.name , m.t, m.y, 
                trunc(dbms_random.value(12346,9999999)) ,p.pro; 
            end loop;
        end loop;
      
        for st in st_csr loop
             execute immediate ins_st  using s.name ,st.sname,
             trunc(dbms_random.value(10000,3562100)),trunc(dbms_random.value(1,10));
        end loop;
        
    end loop;
end;
