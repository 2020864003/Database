drop table temp cascade constraints
/
drop table test cascade constraints
/
create table test (
    name    varchar(100) primary key,
    age     number(3) not null,
    address varchar(200),
    check(age > 10 and age < 110)
)
/
create table temp (
    num     number(3) primary key,
    name    varchar(100) references test(name)
)
/   
insert into test values ('H0', 23, '부산시 남구');
insert into temp values (0, 'H0');

declare
    type    n_type is table of test.name%type;
    type    a_type is table of test.age%type;
    test_n   n_type := n_type('H1', 'H2', 'H3', 'H3', 'H4');
    test_a   a_type := a_type(30, NULL, 28, 40, 5);
    temp_n  n_type := n_type();
    
    sql_str     varchar(200) := 'insert into test values (:1, :2, :3)';
    sql_str1     varchar(200) := 'insert into temp values (:1, :2)';
    
    err1 exception;
    err2 exception;
    err3 exception;
    err4 exception;
    err5 exception;
    pragma exception_init(err1,-2292);
    pragma exception_init(err2,-1400);
    pragma exception_init(err3,-2291);
    pragma exception_init(err4,-1);
    pragma exception_init(err5,-2290);

begin
    temp_n := test_n;
    for i in test_n.first..test_n.last loop
        begin
            execute immediate sql_str using test_n(i), test_a(i), dbms_random.string('x',5)||' '||dbms_random.string('a',10);
            execute immediate sql_str1 using i, temp_n(i);
            if i = test_n.first then
                delete from test
                where name = test_n(i);
            elsif i = 3 then
                update temp
                set name = 'H5'
                where num = 3;
            end if;
        exception
            when err1 then
                dbms_output.put_line('['||i||'] test 테이블에 원하는 순번에 이미 값이 있음!!!');
            when err2 then
                dbms_output.put_line('['||i||'] test 테이블의 age 에 not null 설정되있음 -> NULL값을 넣을수 없음!!');
            when err3 then
                dbms_output.put_line('['||i||'] test 테이블에 없는 값을 넣음 !!!');
            when err4 then
                dbms_output.put_line('['||i||'] test 테이블의 name에 같은값이 이미있음 !!!');
            when err5 then
                dbms_output.put_line('['||i||'] test 테이블의 age 에 check 조약에 위배되는 값!!!');
            
        end;
    end loop;
    dbms_output.put_line(lpad(' ', 50, '*'));
    for t in (select * from test) loop
        dbms_output.put_line(t.name||', '||t.age||', '||t.address);
    end loop;
    dbms_output.put_line(lpad(' ', 50, '*'));
    for t in (select * from temp) loop
        dbms_output.put_line(t.num||', '||t.name);
    end loop;
end;