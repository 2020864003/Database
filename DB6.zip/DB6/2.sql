declare
    type me_ty is table of movieexecinfo%rowtype;
    me   me_ty;
    cursor m_csr is select * from movieexecinfo order by name asc;
    mov movieexecinfo.movies%type;
    stu movieexecinfo.studios%type;
begin
    for m in m_csr loop
        
        dbms_output.put_line('['||m_csr%rowcount||']제작자['||m.name||'] :
        주소['||m.address||'], 재산['||m.networth||']');
        mov := m.movies;
        if mov.count >0 then
            for i in mov.first..mov.last loop
                dbms_output.put_line(lpad('-제목 : ',13)||rpad(mov(i).title||'('||
                mov(i).year||')',28)|| '계약날짜 : '||mov(i).contract_date||', 계약금액 : '||mov(i).salary);
            end loop;
        else
            dbms_output.put_line(lpad('%영화 제작경험 없음',24));
        end if;
       stu := m.studios;
        if stu.count >0 then
            for i in stu.first..stu.last loop
                dbms_output.put_line(lpad('#운영영화사 : ',19)||rpad(stu(i).name,15)||', 직원 수 : '||
                stu(i).emp_count);
                dbms_output.put_line('');
            end loop;
        else
            dbms_output.put_line(lpad('@영화사운영안함',20));
            dbms_output.put_line('');
        end if;
     
         
    end loop;
end;