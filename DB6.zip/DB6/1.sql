declare
    cursor me_csr is select * from  movieexec;
    cursor m_csr(meNo movieexec.certno%type) is 
            select title tt ,year yy from movie where producerno = meNo;
    cursor s_csr(meNo movieexec.certno%type) is
            select name sname from studio where presno = meNo;
    ins_me varchar2(200) := 'insert into MovieExecInfo values (:1,:2,:3,
                        movie_tab(),studio_tab())';
    ins_mm varchar2(200) := 'insert into 
    table(select movies from MovieExecInfo where name =:1) 
    values(movie_ty(:2,:3,:4,:5))';
                        
    ins_st varchar2(200) := 'insert into 
                        table(select studios from MovieExecInfo where name =:1) 
                        values(studio_ty(:2,:3))';
   yyear string(100) := '';
   cdate date;
begin
    for me in me_csr loop
        execute immediate ins_me using me.name, me.address, me.networth;
        for m in m_csr(me.certno) loop
           yyear := m.yy||'-01'||'-01';
           cdate := (to_date(yyear)-trunc(dbms_random.value(1,5*365)));
           
            execute immediate ins_mm  using me.name 
            ,m.tt,m.yy,cdate 
            ,trunc(dbms_random.value(10000,99999999)); 
            
            
        end loop;
        for s in s_csr(me.certno) loop
            execute immediate ins_st  using me.name ,s.sname,dbms_random.value(5,200);
        end loop;
        
    end loop;
end;