create or replace trigger Star_Insert
before insert on moviestar
for each row
declare
    add     moviestar.address%type;
    birth   moviestar.birthdate%type;
    cnt_m   integer;
    cnt_f   integer;
    gen     moviestar.gender%type;
    gen2    moviestar.gender%type;
    pragma  autonomous_transaction;
begin

    if :new.address is null or :new.birthdate is null then
       begin
         select address into add
            from (select address from moviestar 
            order by dbms_random.value) 
            where rownum = 1;

         select birthdate into birth
            from (select birthdate from moviestar 
            order by dbms_random.value) 
            where rownum = 1;
       end;
       if :new.address is null and :new.birthdate is not null then
            :new.address := add;
       elsif :new.birthdate is null and :new.address is not null then
            :new.birthdate := birth;
       elsif :new.address is null and :new.birthdate is null then
            :new.address := add;
            :new.birthdate := birth;
       end if;  
    end if;
    
       if :new.gender is null then
        begin
             select count(gender) into cnt_f from moviestar where gender ='female' and birthdate > birth;
             select count(gender) into cnt_m from moviestar where gender ='male' and birthdate > birth;
             select gender into gen2
             from (select gender from moviestar  order by dbms_random.value) 
             where rownum = 1;
        end;   
        if cnt_m > cnt_f then
            :new.gender := 'male';
            
        elsif cnt_m = cnt_f then
            :new.gender := gen2;
        else
            :new.gender := 'female';
        end if;
    end if;
end;