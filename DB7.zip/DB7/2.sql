create or replace trigger Exec_update
before update on movieexec
for each row
declare
    s_name  movieexec.name%type;
    avg_net movieexec.networth%type;
    b_no    studio.presno%type;
    cnt     integer;
    cnt2    integer;
    cnt3    integer;
    
    pragma  autonomous_transaction;
begin

    select count(presno) into cnt
    from  studio 
    where :old.certno = presno;
    
    select count(producerno) into cnt2
    from  movie 
    where :old.certno = producerno;

    select avg(networth) into avg_net
    from movieexec;
    
    select count(name) into cnt3
    from moviestar
    where name = :old.name;
    
    if cnt > 0 or cnt2 > 0 then
        :new.name := :old.name; 
        if:new.name = :old.name then
        :new.name := :old.name; 
        dbms_output.put_line('movieexec 튜플이 사장 또는 영화 제작자입니다!!!');
        end if;
    else
        if :new.networth > avg_net then
            select presno into b_no
            from (select presno from studio 
            order by dbms_random.value) 
            where rownum = 1;
            
            update  studio
            set     presno = :old.certno , address = :old.address 
            where   presno = b_no;
            commit;    
        end if;
    end if;
      if cnt3 > 0 then
           :new.address := '['|| :old.address || ']에 배우가 삽니다!';
        end if; 
end;